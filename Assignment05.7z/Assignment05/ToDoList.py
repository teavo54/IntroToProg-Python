# Creating Tuple tables
# By: Terry Vo
# April 26, 2019
# Change Log: Lists and Dictionaries.

file_name = 'Todo.txt'
f = open(file_name)
my_dict = {}
while(1):
    line = f.readline()
    if line == '':
        break
    line_split = line.split(',')
    my_dict[line_split[0]] = line_split[1].replace('\n','')
f.close()


row_data = []
for key,value in my_dict.items():
    row_data.append([key,value])


def show_data(row_data):
    for row in row_data:
        print(','.join(ch for ch in row))
 
def add_data(row_data):
    task_name = input('Enter task name to add: ')
    priority = input('Enter priority : ')
    row_data.append([task_name,priority])
    print('Record added')
    
def remove_item(row_data):
    task_name = input('Enter task name to delete : ')
    ctr = -1
    found = False
    for row in row_data:
        ctr = ctr + 1
        if row[0] == task_name:
            found = True
            break
    
    if(found):
        row_data.pop(ctr)
    else:
        print('Not found')
        
def save_to_file(row_data):
    f = open('Todo.txt','w')
    for row in row_data:
        f.write(row[0]+','+row[1]+'\n')
    f.close()
    print('Written')
            

print('Initial Data created')
user_choice = 1
while(user_choice != 5):
    print('Menu')
    print('1. Show current data')
    print('2. Add a new item')
    print('3. Remove an existing item')
    print('4. Save Data to File')
    print('5. Exit Program')
    user_choice = int(input('Enter choice : '))
    if user_choice == 1:
        show_data(row_data)
    elif user_choice == 2:
        add_data(row_data)
    elif user_choice == 3:
        remove_item(row_data)
    elif user_choice == 4:
        save_to_file(row_data)
    else:
        save_to_file(row_data)
        break