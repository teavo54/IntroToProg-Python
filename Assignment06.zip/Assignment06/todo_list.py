# Creating To Do List - pt. 2
# By: Terry Vo
# May 3rd, 2019
# Change Log: Lists and Dictionaries.

row_data = []

class TodoList:
    def read_file(self):
        file_name = 'Todo.txt'
        f = open(file_name)
        my_dict = {}
        while (1):
            line = f.readline()
            if line == '':
                break
            line_split = line.split(',')
            my_dict[line_split[0]] = line_split[1].replace('\n', '')
        f.close()

        for key, value in my_dict.items():
            row_data.append([key, value])


    def show_data(self, row_data):
        for row in row_data:
            print(','.join(ch for ch in row))


    def add_data(self, row_data):
        task_name = input('Enter task name to add: ')
        priority = input('Enter priority : ')
        row_data.append([task_name, priority])
        print('Record added')


    def remove_item(self, row_data):
        task_name = input('Enter task name to delete : ')
        ctr = -1
        found = False
        for row in row_data:
            ctr = ctr + 1
            if row[0] == task_name:
                found = True
                break

        if (found):
            row_data.pop(ctr)
        else:
            print('Not found')


    def save_to_file(self, row_data):
        f = open('Todo.txt', 'w')
        for row in row_data:
            f.write(row[0] + ',' + row[1] + '\n')
        f.close()
        print('Written')


def programDriverFunction():
    todo_list = TodoList()
    todo_list.read_file()
    print('Initial Data created')
    user_choice = 1
    while (user_choice != 5):
        print('Menu')
        print('1. Show current data')
        print('2. Add a new item')
        print('3. Remove an existing item')
        print('4. Save Data to File')
        print('5. Exit Program')
        user_choice = int(input('Enter choice : '))
        if user_choice == 1:
            todo_list.show_data(row_data)
        elif user_choice == 2:
            todo_list.add_data(row_data)
        elif user_choice == 3:
            todo_list.remove_item(row_data)
        elif user_choice == 4:
            todo_list.save_to_file(row_data)
        else:
            todo_list.save_to_file(row_data)
            break

programDriverFunction()