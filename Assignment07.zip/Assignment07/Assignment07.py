# Creating To Do List - pt. 2
# By: Terry Vo
# May 11th, 2019
# Change Log: exception handling and Python’s pickling module


#importing pickle library from packages
import pickle

# Name of file that will be used for saving and retrieving the data using pickle
filename = 'File'

# This is the data that will be saved and retrieved from file using pickle
Dictionary = {'Michael': 1, 'Jordan': 2, 'Clark': 3, 'Pederson': 4, 'Daniel': 5, 'George': 6, 'Jass': 7,
                     'Ben': 8, 'Darren': 9, 'Joe': 10}

# This method will save the dictionary to file using pickle
def pickleObject():
    outfile = open(filename, 'wb')
    print(Dictionary)
    print("Dictionary successfully exported to file!")
    pickle.dump(Dictionary, outfile)
    outfile.close()

# This method will retrieve the data using pickle from file and if file is not found this method will through exception.
def unpickleObject():
    try:
        infile = open(filename, 'rb')
        new_dict = pickle.load(infile)
        print("Type of data: ", type(new_dict))
        infile.close()

        print(new_dict)
    except Exception as e:
        print(e)

# This method needs to be used for blog portion
def blogFunction():
    # Here goes your work for blog


# This is the driver function for this program. It will display menu and ask the user to make selection
def main():
    choice = -1
    while choice != 0:
        print("****************************************************************")
        print("*                         PROGRAM MENU                         *")
        print("****************************************************************")
        print("1. To pickle the object.")
        print("2. To unpickle the object.")
        print("3. To work with blog.")
        print("0. To exit from program.")
        print("----------------------------------------------------------------")
        choice = int(input("Enter your choice: "))
        if choice == 1:
            pickleObject()
        elif choice == 2:
            unpickleObject()
        elif choice == 3:
            blogFunction()
        elif choice == 0:
            print("Exiting the program")
        else:
            print("Please make a valid selection!")
        print('\n\n')


main()
